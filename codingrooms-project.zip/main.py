#https://onlinegdb.com/bi1sEY_c4 ------ Link do GDB

#--------------------- Imports Locais ---------------------#
import Defs as df
import color as col
import Users as us
import bd_coletas as bd
import log
import Pesquisa as pq
from datetime import datetime
#----------------------------------------------------------#

global user
user = None
global data
data = ''
global familia
familia = ''
global genero
genero = ''
global espécie
espécie = ''
global hábito
hábito = ''
global origem
origem = ''
global recurso
recurso = ''
global referencia
referencia = ''
global floração
floração = ''
  
## Banner padrão do logo do Sug-Flora App
# banner = '''   
#   █████████  █████  █████   █████████             ███████████ █████          ███████    ███████████     █████████  
#  ███░░░░░███░░███  ░░███   ███░░░░░███           ░░███░░░░░░█░░███         ███░░░░░███ ░░███░░░░░███   ███░░░░░███ 
# ░███    ░░░  ░███   ░███  ███     ░░░             ░███   █ ░  ░███        ███     ░░███ ░███    ░███  ░███    ░███ 
# ░░█████████  ░███   ░███ ░███          ██████████ ░███████    ░███       ░███      ░███ ░██████████   ░███████████ 
#  ░░░░░░░░███ ░███   ░███ ░███    █████░░░░░░░░░░  ░███░░░█    ░███       ░███      ░███ ░███░░░░░███  ░███░░░░░███ 
#  ███    ░███ ░███   ░███ ░░███  ░░███             ░███  ░     ░███      █░░███     ███  ░███    ░███  ░███    ░███ 
# ░░█████████  ░░████████   ░░█████████             █████       ███████████ ░░░███████░   █████   █████ █████   █████
#  ░░░░░░░░░    ░░░░░░░░     ░░░░░░░░░             ░░░░░       ░░░░░░░░░░░    ░░░░░░░    ░░░░░   ░░░░░ ░░░░░   ░░░░░ 
# Alpha.1.0'''

# Banner padrão do logo do Sug-Flora App
banner = '''
  ____  ____  _____ ____                          
 / ___||  _ \| ____/ ___|                         
 \___ \| |_) |  _|| |                             
  ___) |  __/| |__| |___                          
 |____/|_|   |_____\____| _____ _                 
 / ___| _   _  __ _      |  ___| | ___  _ __ __ _ 
 \___ \| | | |/ _` |_____| |_  | |/ _ \| '__/ _` |
  ___) | |_| | (_| |_____|  _| | | (_) | | | (_| |
 |____/ \__,_|\__, |     |_|   |_|\___/|_|  \__,_|
              |___/                               
Alpha.1.0'''

# Inicia o sistema mostrando a primeira página para o usuário
def intro():
    while True:
        indexes=['Entrar', 'Nova Conta','Encerrar']
            # Opções que o usuário terá nessa tela

        resp = df.options(banner+"\nSeja Bem vindo ao Sistema Único de Gestão de Flora! \nPara começarmos, selecione uma opção abaixo:\n", indexes)
            # Função que vai mostrar o menu para o usuário e retornar o que ele selecionou.
            # A função options retorna o index da opção selecionada pelo usuário da lista 'indexes'.

        if resp==0: #Entrar============================================
            global user
            # se o index retornado for 0, então o usuário escolheu logar.
            user = False

            while user == False:
                # Verifica se a função de login encontrou o usuário e retornou seus dados.

                user = login()
                    # Chama a função de login do main.py que vai colher os dados de login.
                    # A função login() retorna o usuário: ['ID','Nome','Login','Senha']

                if user != False:
                    # Se o login for bem sucedido, chama a tela Menu principal
                    MenuPrincipal()
                else:
                    # Se o login for mal sucedido, informa ao usuário que deu algo errado.
                    bn = banner + "\n\n Credenciais incorretas!! O que deseja fazer?\n"
                        # bn recebe uma string com o Banner e abaixo a descrição

                    opt = ['Tentar novamente','Cadastrar-se','Encerrar']
                        # opt recebe as opções da tela de erro

                    resp = df.options(bn,opt)
                        # Menu do erro, mostra ao usuário o 'bn' e as opções selecionáveis da lista 'opt' e retorna o index da opção escolhida
                    
                    if resp == 0: #Tentar novamente ============================================
                        # Se retornar 0, a opção escolhida é 'Tentar novamente' e ele apenas mantém a repetição.
                        pass
                            # palavra reservada que apenas passa

                    elif resp == 1: #Cadastrar-se ============================================
                        # Se retornar 1, a opção escolhida é 'Cadastre-se' e chama a função para cadastrar um novo usuário.
                        singup()

                    elif resp == 2: #Encerrar ============================================
                        # Se retornar 2, a opção escolhida é 'Encerrar'
                        Exit()
                            #Função criada para printar uma mensagem e encerra o terminal

        elif resp==1: #Nova Conta
            # se o index retornado for 1, então o usuário escolheu se cadastrar.
            singup()
                # Chama a função que vai colher os dados do novo usuário e solicitar ao Users.py que cadastre-o.

        elif resp == 2: #Encerrar============================================
            Exit()

# Função para logar no sistema
def login():
    
    df.Cls()
    user = input(banner + "\nBEM VINDO AO SISTEMA ÚNICO DE GESTÃO FLORAL." + "\n Digite o login de seu usuário: ")
    df.Cls()

    pwd = input(banner+ "\nBEM VINDO AO SISTEMA ÚNICO DE GESTÃO FLORAL." + '\n Digite sua senha: ')
    
    return us.login(user,pwd)
    
# Função para cadastrar um novo usuário no sistema
def singup():
    while True:
        df.Cls()
        name = input(banner+ "\n\nNOVO USUÁRIO" + '\n Antes de começarmos, precisamos saber o seu nome: ')
        df.Cls()
        user = input(banner+ "\n\nNOVO USUÁRIO" + '\n Digite o login que deseja cadastrar: ')
        df.Cls()

        erro = ""
        df.Cls()
        pwd1 = input(banner+ "\n\nNOVO USUÁRIO" + erro + '\n Digite sua senha: ')
        df.Cls()
        pwd2 = input(banner+ "\n\nNOVO USUÁRIO" + '\n Confirme sua senha: ')

        if pwd1 == pwd2:
            tentativa = us.cadastro_cliente(name,user,pwd1)
            if tentativa != False:
                op = df.options(banner + "\n\nCadastro efetuado com sucesso.",['Continuar'])
                break
            else:
                op = df.options(banner + "\n\nOPS!! Algo deu errado, tentar novamente?",['Sim','Não'])
                if op == 0:
                    pass
                else:
                    break
        else:
            erro = col.color("\n AS SENHAS NÃO CORRESPONDEM. TENTE NOVAMENTE.",'vermelho',negrito=True)
        #ir para procedimento de singup
    # newUser(login,senha)

# Função que mostra o Menu principal do usuário
def MenuPrincipal():
    global user
    opt = ['Minhas coletas','Sair']
    resp = df.options(f'{banner}\n\n Bem vindo, {user[1]}!!\n Selecione a opção que deseja: \n',opt)
    # print(resp)

    if resp == 1:
        intro()
    elif resp == 0:
        MinhasColetas()        

# Função do Menu que chamará a tela de coletas em loop
def MinhasColetas():
    global user
    # Tela de coletas

    while True:
                
        MenuColetas()

# Menu que mostra as opções das coletas do usuário
def MenuColetas():
    op = df.options(banner,['\nNova coleta','Minhas coletas','Aplicar Filtro','Relatório','Editar coleta','Excluir coleta','Voltar'])

    if op == 0:
        NewColeta()
    elif op == 1:
        ShowColetas(bd.read(user[0]))    
    elif op == 2:
        setFilter()
    elif op == 3:
        criarRelatorio()      
    elif op == 4:
        EditarColeta()
    elif op == 5:
        exc = delColeta()
    elif op == 6:
        MenuPrincipal()

def criarRelatorio():
    e = datetime.now()
    nomearquivo = "relatórios/Relatório %s-%s-%s %s:%s:%s.txt" % (e.year, e.month, e.day, e.hour, e.minute, e.second)
    relatorio = banner+"\n\n Relatório emitido em %s/%s/%s %s:%s:%s." % (e.year, e.month, e.day, e.hour, e.minute, e.second)
    relatorio = relatorio + "\n Emitido por: %s\n" % (user[1])
    relatorio = relatorio + "-"*150
    # relatorio = relatorio + "\n QUANTITATIVO \n\n \t\t\t\t Descrição \t\t\t\t Qtd \t\t\t\t % \t"
    relatorio = relatorio + f"\nQUANTITATIVO\n\n{'Descrição':<30}|{'Qtd':^5}|{'%':^9}|"

    coletas = bd.read(user[0])
    qtdColetas = len(coletas)

    relatorio = relatorio + f'\n{"Quantidade de Coletas:":<30}|{qtdColetas:^15}|'
    
    identificadas = len(pq.identificados(bd.read(user[0])))
    Nidentificadas = qtdColetas - identificadas

    relatorio = relatorio + f'\n{"Coletas Identificadas:":<30}|{identificadas:^5}|{100*(identificadas/qtdColetas):^8}%|'
    relatorio = relatorio + f'\n{"Coletas Não Identificadas:":<30}|{Nidentificadas:^5}|{100*(Nidentificadas/qtdColetas):^8}%|'

    familiasID = len(pq.Fidentificados(coletas))
    familiasNID = len(pq.FNidentificados(coletas))
    GenID = len(pq.Gidentificados(coletas))
    GenNID = len(pq.GNidentificados(coletas))
    EspécieID = len(pq.Eidentificados(coletas))
    EspécieNID = len(pq.ENidentificados(coletas))
    
    relatorio = relatorio + f'\n\n{"Famílias Identificadas:":<30}|{familiasID:^5}|{100*(familiasID/qtdColetas):^8}%|'
    relatorio = relatorio + f'\n{"Famílias Não Identificadas:":<30}|{familiasNID:^5}|{100*(familiasNID/qtdColetas):^8}%|'
    
    relatorio = relatorio + f'\n\n{"Gêneros Identificadas:":<30}|{GenID:^5}|{100*(GenID/qtdColetas):^8}%|'
    relatorio = relatorio + f'\n{"Gêneros Não Identificadas:":<30}|{GenNID:^5}|{100*(GenNID/qtdColetas):^8}%|'
    
    relatorio = relatorio + f'\n\n{"Espécies Identificadas:":<30}|{EspécieID:^5}|{100*(EspécieID/qtdColetas):^8}%|'
    relatorio = relatorio + f'\n{"Espécies Não Identificadas:":<30}|{EspécieNID:^5}|{100*(EspécieNID/qtdColetas):^8}%|'

    relatorio = relatorio + '\n\nCOLETAS\n\n' + SaveColetas(coletas)

    arquivo = open(nomearquivo, 'a+')
    arquivo.writelines(relatorio)
    df.Cls()
    print(relatorio)
    input('\nPressione qualquer tecla para continuar...')
    df.Cls()
    
# Função que vai colher os dados da coleta que o usuário deseja excluir/deletar
def delColeta():
    global user
    coletas = bd.read(user[0])
    selected = selectColeta(coletas)
    
    confirm = df.options(banner + '\n\nTem certeza que deseja excluir a coleta: ' + str(coletas[selected]).replace("'",'').strip('[]') + '??',['Sim','Não quero mais'])
    if confirm == 0:
        bd.excluir(coletas[selected][0])
        df.Cls()
        print(banner + "\n\nCOLETA " + col.color(str(coletas[selected]).replace("'",'').strip('[]'),"vermelho","branco",negrito=True) + col.color(" EXCLUÍDA!!",'vermelho',negrito=True))
        input('\nTecle Enter para continuar...')
    
    else:
        return False
   
# Função que define o filtro a ser feito nas coletas | É um novo menu que não vai influênciar o banco de dados
def setFilter():        
    bdFiltro = bd.read(user[0])
    titulos = ['ID','Data','Família','Gênero','Espécie','Hábito','Origem','Recurso','Referência','Flor','Cancelar','Resetar Filtro']

    while True:
        fil = df.options(banner+'\n\nO que quer filtrar: ',titulos)

        if fil == 0: #ID
            
            op = ['Escrever','Terminar'] + Unique(bdFiltro,0)
            escolha = df.options(banner+'\n\nSelecione o ID a ser filtrado: ',op)

            if escolha == 0:
                print(banner + '\n\nEscreva o ID que quer filtrar: \n')
                escolha = input('')
            elif escolha == 1:
                ShowColetas(bdFiltro)
                pass
            else:
                escolha = op[escolha]   
    
            log.NewLog("main.Minhas coletas",escolha)
            bdFiltro = pq.pesquisa(escolha,bdFiltro)
            ShowColetas(bdFiltro)

        elif fil == 1: #DATA
            
            op = ['Escrever','Terminar'] + Unique(bdFiltro,2)
            escolha = df.options(banner+'\n\nSelecione a data a ser filtrada: ',op)

            if escolha == 0:
                print(banner + '\n\nEscreva a Data que quer filtrar: \n')
                escolha = input('')
            elif escolha == 1:
                ShowColetas(bdFiltro)
                pass
            else:
                escolha = op[escolha]   

            bdFiltro = pq.pesquisa(escolha,bdFiltro)
            ShowColetas(bdFiltro)
        
        elif fil == 2: #Familia
            op = ['Escrever','Terminar'] + Unique(bdFiltro,3)
            escolha = df.options(banner+'\n\nSelecione a Família a ser filtrado: ',op)

            if escolha == 0:
                print(banner + '\n\nEscreva a Família que quer filtrar: \n')
                escolha = input('')
            elif escolha == 1:
                ShowColetas(bdFiltro)
                break
            else:
                escolha = op[escolha]   
    
            log.NewLog("main.Minhas coletas",escolha)
            bdFiltro = pq.pesquisa(escolha,bdFiltro)
            ShowColetas(bdFiltro)

            pass
        elif fil == 3: #Genero
            op = ['Escrever','Terminar'] + Unique(bdFiltro,4)
            escolha = df.options(banner+'\n\nSelecione o Gênero a ser filtrado: ',op)

            if escolha == 0:
                print(banner + '\n\nEscreva o Gênero que quer filtrar: \n')
                escolha = input('')
            elif escolha == 1:
                ShowColetas(bdFiltro)
                break
            else:
                escolha = op[escolha]   
    
            log.NewLog("main.Minhas coletas",escolha)
            bdFiltro = pq.pesquisa(escolha,bdFiltro)
            ShowColetas(bdFiltro)
            pass
        elif fil == 4: #Espécie
            op = ['Escrever','Terminar'] + Unique(bdFiltro,5)
            escolha = df.options(banner+'\n\nSelecione a Espécie a ser filtrado: ',op)

            if escolha == 0:
                print(banner + '\n\nEscreva a Espécie que quer filtrar: \n')
                escolha = input('')
            elif escolha == 1:
                ShowColetas(bdFiltro)
                break
            else:
                escolha = op[escolha]   
    
            log.NewLog("main.Minhas coletas",escolha)
            bdFiltro = pq.pesquisa(escolha,bdFiltro)
            ShowColetas(bdFiltro)
            pass
        elif fil == 5: #Habito
            op = ['Escrever','Terminar'] + Unique(bdFiltro,6)
            escolha = df.options(banner+'\n\nSelecione o Hábito a ser filtrado: ',op)

            if escolha == 0:
                print(banner + '\n\nEscreva o Hábito que quer filtrar: \n')
                escolha = input('')
            elif escolha == 1:
                ShowColetas(bdFiltro)
                break
            else:
                escolha = op[escolha]   
    
            log.NewLog("main.Minhas coletas",escolha)
            bdFiltro = pq.pesquisa(escolha,bdFiltro)
            ShowColetas(bdFiltro)
            pass
        elif fil == 6: #Origem
            op = ['Escrever','Terminar'] + Unique(bdFiltro,7)
            escolha = df.options(banner+'\n\nSelecione a Origem a ser filtrado: ',op)

            if escolha == 0:
                print(banner + '\n\nEscreva a Origem que quer filtrar: \n')
                escolha = input('')
            elif escolha == 1:
                ShowColetas(bdFiltro)
                break
            else:
                escolha = op[escolha]   
    
            log.NewLog("main.Minhas coletas",escolha)
            bdFiltro = pq.pesquisa(escolha,bdFiltro)
            ShowColetas(bdFiltro)
            pass
        elif fil == 7: #Recurso
            op = ['Escrever','Terminar'] + Unique(bdFiltro,8)
            escolha = df.options(banner+'\n\nSelecione o Recurso a ser filtrado: ',op)

            if escolha == 0:
                print(banner + '\n\nEscreva o Recurso que quer filtrar: \n')
                escolha = input('')
            elif escolha == 1:
                ShowColetas(bdFiltro)
                break
            else:
                escolha = op[escolha]   
    
            log.NewLog("main.Minhas coletas",escolha)
            bdFiltro = pq.pesquisa(escolha,bdFiltro)
            ShowColetas(bdFiltro)
            pass
        elif fil == 8: #Referência
            op = ['Escrever','Terminar'] + Unique(bdFiltro,9)
            escolha = df.options(banner+'\n\nSelecione a Referência a ser filtrado: ',op)

            if escolha == 0:
                print(banner + '\n\nEscreva a Referência que quer filtrar: \n')
                escolha = input('')
            elif escolha == 1:
                ShowColetas(bdFiltro)
                break
            else:
                escolha = op[escolha]   
    
            log.NewLog("main.Minhas coletas",escolha)
            bdFiltro = pq.pesquisa(escolha,bdFiltro)
            ShowColetas(bdFiltro)
            pass
        elif fil == 9: #Flor
            op = ['Escrever','Terminar'] + Unique(bdFiltro,10)
            escolha = df.options(banner+'\n\nSelecione a floração a ser filtrada: ',op)

            if escolha == 0:
                print(banner + '\n\nEscreva a floração que quer filtrar: \n')
                escolha = input('')
            elif escolha == 1:
                ShowColetas(bdFiltro)
                break
            else:
                escolha = op[escolha]   
    
            log.NewLog("main.Minhas coletas",escolha)
            bdFiltro = pq.pesquisa(escolha,bdFiltro)
            ShowColetas(bdFiltro)
            pass
        elif fil == 10: #Cancelar
            break
        elif fil == 11: #Resetar Filtro
            bdFiltro = bd.read(user[0])
            pass

# Função que vai permitir que o ususário selecione a coleta a ser editada e altere cada uma das informações dessa coleta
def EditarColeta():
    # Edição da coleta

    coletas = bd.read(user[0])
    selected = coletas[selectColeta(coletas)]

    if selected != []:
        opt = ['Data', 'Familia','Gênero','Especie','Hábito','Origem','Recursos','Referência','Floração', 'Cancelar']

        while True:
            sel_edit = df.options(banner, opt)
            if sel_edit is not None and sel_edit != 9:
                df.Cls()
                content = input(banner + "\n\n Digite um novo valor para " + opt[sel_edit] + ":\n")
                if content is not None and len(content) > 0:
                    selected[sel_edit+2] = content
                    # if selected[sel_edit+2] == content:
                    #     # log.NewLog("Main.Selected", "IGUAIS!")
                    #     # log.NewLog("Main.Selected", selected)
                    # else:
                    #     # log.NewLog("Main.Selected", "DIFERENTES! " + selected[sel.edit+2] + " <-> " + content)
                    bd.editar(selected)
            else:
                break

# Função que recebe um banco de coletas, mostra ao usuário e permite que ele selecione a coleta e retorna os dados da coleta selecionada pelo usuário
def selectColeta(bd):
    selected = []
    coletas= bd
    coletasfmt = []

    for i in range(len(coletas)):
        iString = f'{coletas[i][0]:<3}'+f'{coletas[i][2]:<13}'+f'{coletas[i][3]:<15}'+f'{coletas[i][4]:<15}'+f'{coletas[i][5]:<15}'+f'{coletas[i][6]:<15}'+f'{coletas[i][7]:<15}'+f'{coletas[i][8]}'
        
        if len(iString)> 1:
            coletasfmt.append(iString)

    titulos = ['ID','Data','Família','Gênero','Espécie','Hábito','Origem','Recurso','Referência','Flor']
    

    editcoleta = df.options(banner + f'\n\n{titulos[0]:<3}' + f'{titulos[1]:<13}' + f'{titulos[2]:<15}' + f'{titulos[3]:<15}' + f'{titulos[4]:<15}' + f'{titulos[5]:<15}' + f'{titulos[6]:<15}' + f'{titulos[7]:<15}', coletasfmt)

    return editcoleta    

# Função que coleta as informações da nova coleta e chama a função do banco de dados que insere no arquivo txt
def NewColeta():
    global data
    global familia
    global genero
    global espécie
    global hábito
    global origem
    global recurso
    global referencia
    global floração

    dt = datetime.today()
    dt = [f'{dt.day}/{dt.month}/{dt.year}']

    data = Escolha('Qual a data da coleta?',dt)

    fam = Unique(bd.read(str(user[0])),3)
    df.Cls()
    familia = Escolha('Escolha ou escreva a Família da nova coleta: ',fam)

    genero = []

    generos = [generos[4] for generos in bd.read(user[0]) if generos[3] == familia]

    df.Cls()
    genero = Escolha('Escolha ou escreva o Gênero da nova coleta: ',generos)

    espécies = [espécies[5] for espécies in bd.read(user[0]) if espécies[4] == genero]

    df.Cls()
    espécie = Escolha('Escolha ou escreva a Espécie da nova coleta: ',espécies)

    df.Cls()
    hábito = Escolha('Escolha ou escreva o Hábito da coleta:', ['Erva','Trepadeira','Arbusto','Árvore'])
    df.Cls()
    origem = Escolha('Escolha ou escreva a Origem da coleta:',['Nativa','Exótica','N/Id'])
    df.Cls()
    recurso = Escolha('Escolha ou escreva o Recurso da coleta:',['Pólen','Néctar','N/Id'])
    df.Cls()
    referencia = Escolha('Escolha ou escreva a Referência da coleta: ',['N/Id'])
    df.Cls()
    floração = Escolha('A coleta estava Florida(Fértil)? ',['Sim','Não'])
    df.Cls()

    registro = data + "," + familia + "," + genero + "," + espécie + "," + hábito + "," + origem + "," + recurso + "," + referencia + "," + floração
    
    bd.insert(user[0],registro)

# Função que recebe um banco de coletas, e retira as duplicadas da coluna e retorna uma lista desses itens 
def Unique(bd,index):

    Unique = []

    # log.NewLog('main.Unique',bd)

    for Uniq in bd:
        log.NewLog('main.Unique',Uniq)
        if Uniq[index] not in Unique:
            Unique.append(Uniq[index])

    return Unique

# Função que recebe uma lista de items a ser selecionado pelo usuário, mas permite que ele mesmo escreva o que quer
def Escolha(cabeçalho,bd):
    global data
    global familia
    global genero
    global espécie
    global hábito
    global origem
    global recurso
    global referencia
    global floração

    escolhas = f"\n\nData: {data} | Fam: {familia} | Gên: {genero} | Esp: {espécie}\nHáb: {hábito} | Ori: {origem} | Rec: {recurso} | Ref: {referencia} | Flor: {floração}\n\n"

    dados = ['\nEscrever'] + bd
    escolha = df.options(banner + escolhas + cabeçalho,dados)
    
    if escolha == 0:
        escolha = input(banner + '\n' + cabeçalho + '\n').capitalize()
        df.Cls()
    else:
        escolha = dados[escolha]

    return escolha

# Função que recebe um banco de coletas e retorna para o terminal uma lista das coletas selecionadas
def ShowColetas(bd):

    titulos = ['ID','Data','Família','Gênero','Espécie','Hábito','Origem','Recurso','Referência','Flor']
    coletas = ""
    
    coletas = coletas + f'{titulos[0]:<3}' + f'{titulos[1]:<12}' + f'{titulos[2]:<15}' + f'{titulos[3]:<15}' + f'{titulos[4]:<15}' + f'{titulos[5]:<15}' + f'{titulos[6]:<15}' + f'{titulos[7]:<15}' + f'{titulos[8]:<15}' + f'{titulos[9]:<15}'
    
    for i in bd:

        coletas = coletas + f'\n{i[0]:<3}' + f'{i[2]:<12}' + f'{i[3]:<15}' + f'{i[4]:<15}' + f'{i[5]:<15}' + f'{i[6]:<15}' + f'{i[7]:<15}' + f'{i[8]:<15}' + f'{i[9]:<15}' + f'{i[10]:<15}'

    df.Cls()
    print(banner)
    print(coletas)
    input('\nEnter para continuar...')
    df.Cls()
    return coletas

def SaveColetas(bd):

    titulos = ['ID','Data','Família','Gênero','Espécie','Hábito','Origem','Recurso','Referência','Flor']
    coletas = ""
    
    coletas = coletas + f'{titulos[0]:<3}' + f'{titulos[1]:<12}' + f'{titulos[2]:<15}' + f'{titulos[3]:<15}' + f'{titulos[4]:<15}' + f'{titulos[5]:<15}' + f'{titulos[6]:<15}' + f'{titulos[7]:<15}' + f'{titulos[8]:<15}' + f'{titulos[9]:<15}'
    
    for i in bd:

        coletas = coletas + f'\n{i[0]:<3}' + f'{i[2]:<12}' + f'{i[3]:<15}' + f'{i[4]:<15}' + f'{i[5]:<15}' + f'{i[6]:<15}' + f'{i[7]:<15}' + f'{i[8]:<15}' + f'{i[9]:<15}' + f'{i[10]:<15}'
    return coletas

# Fuñção que printa uma mensagem de despedida e encerra o terminal
def Exit():
    df.Cls()
    print('Muito obrigado por usar o SuGFlora')
    exit()

intro()