
def conUser(metodo,bd_user=''):
    bd_users = []
    users = open("Banco de dados/bd_users.txt",metodo)
    
    if metodo == "r":
        for i in users:
            bd_users.append(i.strip('\n').split(','))
        return bd_users
    elif metodo == "w":

        for i in bd_user:
            texto = 



        user.write(bd_user)
        users = open("Banco de dados/bd_users.txt",'r')

        for i in users:
            bd_users.append(i.strip('\n').split(','))
        return bd_users
    

print(conUser("r"))