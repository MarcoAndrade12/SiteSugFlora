#imports essenciais
import Defs as df
import Users2 as us
import os


#Janela de login
user = False
log1 = None

while log1 != 1 and log1 != 2 and log1 != 3:
    df.Cls()
    df.Div()
    print("  BEM VINDO AO SUG-FLORA APP")
    print("  O que deseja fazer?")
    print("  1 - Logar")
    print("  2 - Cadastrar-se")
    print("  3 - Encerrar")
    df.Div()
    if log1 == 4:
        print("  DIGITE APENAS 1, 2 OU 3!!")
    log1 = int(input("  O que deseja fazer: "))
    if log1 != 1 and log1 != 2 and log1 != 3:
        log1 = 4

if log1 == 1:
    while True:
            
        df.Cls()
        df.Div()
        print("  BEM VINDO AO SUG-FLORA APP")
        print("  Faça login para continuar")
        df.Div()

        login = str(input('  Digite o Login: '))
    
        df.Cls()
        df.Div()
        print("  BEM VINDO AO SUG-FLORA APP")
        print("  Faça login para continuar")
        df.Div()
        senha = str(input('  Digite a senha: '))
        df.Cls()

        
        user = us.Login(login,senha)

        if user == False:
            df.Div()
            print("  TENTATIVA DE LOGIN")
            print("      FRACASSOU!")
            print("  1 - Tentar novamente")
            print("  2 - Cadastrar novo")
            print("  3 - Encerrar")
            df.Div()

            tlf = int(input("Digite a opção: "))
            if tlf == 1:
                pass
            elif tlf == 2:
                newus = us.newUser()
                if newus:
                    print("Usuário criado")
                else:
                    print("Operação cancelada")

            elif tlf == 3:
                df.Cls()
                df.Div()
                print("  SUGFLORA ENCERRADO")
                print("  OBRIGADO POR USAR")
                df.Div()
                exit()



    else:

        print('Bem vindo, ',user[1])

    



if log1 == 2:
    pass